<?php
header('Location: /frontend/acceuil.html');
exit;
?>

<!-- ce fichier il faut afin de rediriger vers la page d'acceuil quand on ouvre le web depuis le docker -->