<?php
return [
    // local Docker
    'DB_HOST' => 'mysql',
    'DB_NAME' => 'mediastock',
    'DB_USER' => 'mediastock',
    'DB_PASSWORD' => 'changeme'

];

# Exemple de fichier env.php pour MediaStock
# référence pour tous les devs (quelles variables existent, avec quelles clés)

?>